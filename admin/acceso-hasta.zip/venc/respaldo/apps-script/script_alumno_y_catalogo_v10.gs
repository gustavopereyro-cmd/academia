/**
 * ============================================================
 *  CLASSROOM DEL ALUMNO + CATÁLOGO PÚBLICO - ACADEMIA VIRTUAL
 *  Backend (Google Apps Script) — v10: despertador opcional (instalarDespertador) + v9: "Olvidé mi contraseña" + examen final multiple choice (además de caché por versión,
 *  avance del alumno y novedades del catálogo)
 * ============================================================
 *  ACCIONES DISPONIBLES:
 *   - loginAlumno          → login de alumnos (devuelve token + sus cursos)
 *   - getCursosAlumno      → cursos + clases + materiales + certificados del alumno (requiere token)
 *   - marcarAvance         → registra contenido visto / clase completada (requiere token)
 *   - pedirNuevaClave      → manda un mail con un link para crear una contraseña nueva
 *   - restablecerClave     → guarda la contraseña nueva usando el link del mail
 *   - iniciarExamen        → empieza (o retoma) el examen final del curso (requiere token)
 *   - enviarExamen         → corrige el examen en el servidor y guarda el resultado (requiere token)
 *   - GET ?action=catalogo → catálogo público liviano (sin login)
 *   - GET ?action=detalle  → página del curso publicado: descripción, nivel, requisitos,
 *                            temario (solo nombres, sin links) y preguntas frecuentes
 *   - GET ?action=limpiarCache&key=... → limpia el caché (lo llama el panel admin)
 *
 *  INSTRUCCIONES:
 *   1. Reemplazá TODO el código del proyecto por este archivo.
 *   2. Implementar → Administrar implementaciones → ✏️
 *      → Versión: NUEVA VERSIÓN → Implementar.
 * ============================================================
 */

const SHEET_ID = '1S3eWZIwIbpdIJv35GPd3JI_Mp3v5fy0MTCG13YQzEYw';

// Clave compartida con el panel admin para limpiar el caché.
// Tiene que ser EXACTAMENTE igual a la del script del panel.
const CLAVE_LIMPIEZA = 'FK6KLsJTMv9cxSIjeOkr8_o1Ls-zOkkC';

// Duración del caché en segundos (600 = 10 minutos).
// Si editás la planilla a mano (sin el panel), los cambios aparecen en hasta 10 minutos.
const CACHE_TTL_SECONDS = 600;
const CACHE_KEY_CATALOGO = 'catalogo_publico_v6';
const CACHE_KEY_CONTENIDO = 'contenido_v6';

// ---- Examen final (las columnas tienen que ser iguales a las del script del panel) ----
const HOJA_EXAMENES = 'Examenes';
const HOJA_PREG_EXAMEN = 'Examen_Preguntas';
const HOJA_RESULTADOS = 'Resultados_Examen';
const COLUMNAS_RESULTADOS = ['ID_Intento', 'ID_Alumno', 'ID_Curso', 'ID_Examen', 'Intento', 'Estado',
  'Inicio', 'Fin', 'Limite_Ms', 'Orden_Preguntas', 'Respuestas', 'Correctas', 'Total', 'Puntaje', 'Aprobado'];
// Margen después del tiempo límite para que llegue el envío automático (3 minutos)
const GRACIA_EXAMEN_MS = 3 * 60 * 1000;

// ---- Seguridad ----
const DURACION_SESION_SEG = 12 * 60 * 60;  // la sesión del alumno dura 12 horas
const MAX_INTENTOS_LOGIN = 5;              // intentos fallidos permitidos
const BLOQUEO_LOGIN_SEG = 10 * 60;         // tiempo de bloqueo: 10 minutos

/* ============================================================
   LECTURA DE LA PLANILLA
   ============================================================ */

let _ss = null;
function getSS() { return _ss || (_ss = SpreadsheetApp.openById(SHEET_ID)); }

function getSheetByName(name) {
  const sheet = getSS().getSheetByName(name);
  if (!sheet) throw new Error('No se encontró la hoja "' + name + '"');
  return sheet;
}

/** Convierte una hoja en objetos leyendo todo en UNA sola llamada. */
function sheetToObjects(sheetName) {
  const values = getSheetByName(sheetName).getDataRange().getValues();
  if (values.length < 2) return [];
  const headers = values[0];
  const items = [];
  for (let i = 1; i < values.length; i++) {
    const row = values[i];
    if (row.every(c => c === '' || c === null)) continue;
    const obj = {};
    for (let k = 0; k < headers.length; k++) obj[headers[k]] = row[k];
    items.push(obj);
  }
  return items;
}

/** Ordena cursos según columna "Orden" (si existe) o por ID_Curso */
function ordenarCursos(cursos) {
  const tieneOrden = cursos.length > 0 && cursos[0].hasOwnProperty('Orden');
  if (tieneOrden) {
    return cursos.slice().sort((a, b) => {
      const oa = Number(a.Orden); const ob = Number(b.Orden);
      const na = isNaN(oa) ? 999999 : oa;
      const nb = isNaN(ob) ? 999999 : ob;
      return na - nb;
    });
  }
  return cursos.slice().sort((a, b) =>
    String(a.ID_Curso || '').localeCompare(String(b.ID_Curso || ''))
  );
}

function respond(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

/* ============================================================
   CACHÉ EN TROZOS (cada valor de caché admite ~100 KB)
   ============================================================ */

const TAM_TROZO = 30000; // caracteres por trozo (margen para tildes y símbolos)

function cachePutGrande(clave, texto, ttl) {
  const n = Math.max(1, Math.ceil(texto.length / TAM_TROZO));
  const trozos = {};
  for (let i = 0; i < n; i++) trozos[clave + '_' + i] = texto.substr(i * TAM_TROZO, TAM_TROZO);
  trozos[clave] = String(n);
  CacheService.getScriptCache().putAll(trozos, ttl);
}

function cacheGetGrande(clave) {
  const cache = CacheService.getScriptCache();
  const n = Number(cache.get(clave));
  if (!n) return null;
  const claves = [];
  for (let i = 0; i < n; i++) claves.push(clave + '_' + i);
  const partes = cache.getAll(claves);
  let texto = '';
  for (let i = 0; i < claves.length; i++) {
    const p = partes[claves[i]];
    if (p === undefined || p === null) return null;
    texto += p;
  }
  return texto;
}

function cacheBorrarGrande(clave) {
  const cache = CacheService.getScriptCache();
  const n = Number(cache.get(clave)) || 0;
  const claves = [clave];
  for (let i = 0; i < n; i++) claves.push(clave + '_' + i);
  cache.removeAll(claves);
}

/**
 * Versión del contenido: el panel la cambia (hoja Config, celda B2)
 * cada vez que agrega, edita o borra un curso, clase o contenido.
 */
let _version = null;
function getVersionContenido() {
  if (_version !== null) return _version;
  try {
    const sh = getSS().getSheetByName('Config');
    _version = sh ? String(sh.getRange('B2').getValue() || '') : '';
  } catch (e) { _version = ''; }
  return _version;
}

/**
 * Cursos + clases + contenidos ya armados y ordenados.
 * Se guarda en caché para no leer 3 hojas en cada ingreso; si el panel
 * cambió algo (versión distinta), se vuelve a leer la planilla en el acto.
 */
function getContenido() {
  const version = getVersionContenido();
  try {
    const t = cacheGetGrande(CACHE_KEY_CONTENIDO);
    if (t) {
      const c = JSON.parse(t);
      if (c.version === version) return c;
    }
  } catch (e) { /* si el caché falla, se lee la planilla */ }

  const porOrden = (a, b) => (Number(a.Orden) || 0) - (Number(b.Orden) || 0);

  const cursos = ordenarCursos(sheetToObjects('Cursos')).map(c => ({
    ID_Curso: String(c.ID_Curso),
    Nombre: c.Nombre,
    Descripcion_Programa: c.Descripcion_Programa,
    Descripcion_Larga: c.Descripcion_Larga,
    Imagen_URL: c.Imagen_URL,
    Duracion: c.Duracion,
    Nivel: c.Nivel || '',
    Requisitos: c.Requisitos || '',
    Destacado: String(c.Destacado || '').trim().toLowerCase() === 'si',
    Etiqueta: String(c.Etiqueta || '').trim(),
    Fecha_Inicio_Curso: fechaISO(c.Fecha_Inicio_Curso),
    Precio_ARS: c.Precio_ARS,
    Precio_USD: c.Precio_USD,
    Fecha_Inicio_Publicacion: c.Fecha_Inicio_Publicacion,
    Fecha_Fin_Publicacion: c.Fecha_Fin_Publicacion
  }));

  const matPorClase = {};
  sheetToObjects('Materiales').forEach(m => {
    const k = String(m.ID_Clase);
    (matPorClase[k] = matPorClase[k] || []).push(m);
  });

  const clasesPorCurso = {};
  sheetToObjects('Clases').forEach(cl => {
    const k = String(cl.ID_Curso);
    (clasesPorCurso[k] = clasesPorCurso[k] || []).push(cl);
  });

  const clasesArmadas = {};
  Object.keys(clasesPorCurso).forEach(k => {
    clasesArmadas[k] = clasesPorCurso[k].sort(porOrden).map(cl => ({
      ID_Clase: cl.ID_Clase,
      Orden: cl.Orden,
      Titulo: cl.Titulo,
      Contenidos: (matPorClase[String(cl.ID_Clase)] || []).sort(porOrden)
        .map(m => ({ ID: String(m.ID_Material || ''), Tipo: m.Tipo, Nombre: m.Nombre, Link: m.Link, Orden: m.Orden }))
    }));
  });

  // Preguntas frecuentes (las mismas para todos los cursos). Si la hoja no existe, no hay preguntas.
  let preguntas = [];
  if (getSS().getSheetByName('Preguntas_Frecuentes')) {
    preguntas = sheetToObjects('Preguntas_Frecuentes')
      .filter(q => String(q.Pregunta || '').trim())
      .sort(porOrden)
      .map(q => ({ Pregunta: String(q.Pregunta), Respuesta: String(q.Respuesta || '') }));
  }

  // Examen final de cada curso (con las respuestas correctas: esto queda SOLO en el servidor)
  const examenesPorCurso = {};
  if (getSS().getSheetByName(HOJA_EXAMENES)) {
    const pregPorExamen = {};
    if (getSS().getSheetByName(HOJA_PREG_EXAMEN)) {
      sheetToObjects(HOJA_PREG_EXAMEN).forEach(p => {
        const k = String(p.ID_Examen);
        (pregPorExamen[k] = pregPorExamen[k] || []).push(p);
      });
    }
    sheetToObjects(HOJA_EXAMENES).forEach(x => {
      const preguntasEx = (pregPorExamen[String(x.ID_Examen)] || []).sort(porOrden)
        .filter(p => String(p.Pregunta || '').trim() && String(p.Correcta || '').trim())
        .map(p => ({
          ID: String(p.ID_PreguntaEx),
          Pregunta: String(p.Pregunta),
          Opciones: ['A', 'B', 'C', 'D']
            .filter(l => String(p['Opcion_' + l] || '').trim())
            .map(l => ({ L: l, T: String(p['Opcion_' + l]) })),
          Correcta: String(p.Correcta).trim().toUpperCase()
        }));
      examenesPorCurso[String(x.ID_Curso)] = {
        ID_Examen: String(x.ID_Examen),
        Titulo: String(x.Titulo || 'Examen final'),
        Instrucciones: String(x.Instrucciones || ''),
        Nota_Minima: Number(x.Nota_Minima) || 70,
        Intentos_Max: Number(x.Intentos_Max) || 1,
        Tiempo_Min: Number(x.Tiempo_Min) || 0,
        Mezclar: String(x.Mezclar || '').trim().toLowerCase() === 'si',
        Publicado: String(x.Estado || '').trim().toLowerCase() === 'publicado',
        Preguntas: preguntasEx
      };
    });
  }

  const contenido = { version: version, cursos: cursos, clasesPorCurso: clasesArmadas, preguntas: preguntas,
    examenesPorCurso: examenesPorCurso };
  try {
    cachePutGrande(CACHE_KEY_CONTENIDO, JSON.stringify(contenido), CACHE_TTL_SECONDS);
  } catch (e) {
    console.warn('No se pudo cachear el contenido: ' + e.message);
  }
  return contenido;
}

/** Fecha de la planilla → 'AAAA-MM-DD' (vacío si no hay o no es fecha). */
function fechaISO(v) {
  if (v === '' || v === null || v === undefined) return '';
  const d = (Object.prototype.toString.call(v) === '[object Date]') ? v : new Date(v);
  if (isNaN(d.getTime())) return '';
  return Utilities.formatDate(d, Session.getScriptTimeZone(), 'yyyy-MM-dd');
}

function limpiarTodoElCache() {
  CacheService.getScriptCache().remove(CACHE_KEY_CATALOGO);
  cacheBorrarGrande(CACHE_KEY_CONTENIDO);
}

/* ============================================================
   SEGURIDAD: tokens firmados + límite de intentos
   ============================================================ */

/** Clave secreta para firmar tokens. Se crea sola la primera vez. */
function getSecreto() {
  const props = PropertiesService.getScriptProperties();
  let secreto = props.getProperty('SECRETO_TOKEN');
  if (secreto) return secreto;
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    secreto = props.getProperty('SECRETO_TOKEN');
    if (!secreto) {
      secreto = Utilities.getUuid() + Utilities.getUuid() + Utilities.getUuid();
      props.setProperty('SECRETO_TOKEN', secreto);
    }
  } finally {
    lock.releaseLock();
  }
  return secreto;
}

function firmar(texto) {
  return Utilities.base64EncodeWebSafe(Utilities.computeHmacSha256Signature(texto, getSecreto()));
}

function igualesSeguro(a, b) {
  a = String(a); b = String(b);
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

function crearToken(datos, duracionSeg) {
  const payload = Object.assign({}, datos, { exp: Date.now() + duracionSeg * 1000 });
  const p = Utilities.base64EncodeWebSafe(JSON.stringify(payload), Utilities.Charset.UTF_8);
  return p + '.' + firmar(p);
}

/** Devuelve los datos del token si es válido y no venció; si no, null. */
function leerToken(token) {
  if (!token || typeof token !== 'string') return null;
  const partes = token.split('.');
  if (partes.length !== 2) return null;
  if (!igualesSeguro(firmar(partes[0]), partes[1])) return null;
  try {
    const bytes = Utilities.base64DecodeWebSafe(partes[0]);
    const payload = JSON.parse(Utilities.newBlob(bytes).getDataAsString('UTF-8'));
    if (!payload.exp || Date.now() > payload.exp) return null;
    return payload;
  } catch (e) {
    return null;
  }
}

/* ============================================================
   OLVIDÉ MI CONTRASEÑA
   - El alumno pide un link; le llega por mail y vale 1 hora.
   - El link sirve una sola vez: deja de valer apenas se cambia la contraseña.
   - Nunca se dice si un mail está o no registrado.
   ============================================================ */

// Direcciones del aula que pueden ir en el link del mail (nunca una que mande el navegador)
const URLS_AULA_PERMITIDAS = [
  'https://academia.institutomarianabarrera.com.ar/aula/',
  'https://gustavopereyro-cmd.github.io/academia/aula/'
];
const DURACION_LINK_CLAVE_SEG = 60 * 60;        // 1 hora
const ESPERA_ENTRE_MAILS_SEG = 5 * 60;          // como mucho 1 mail cada 5 minutos por alumno

function huellaClave(password) {
  return firmar('clave:' + String(password === undefined || password === null ? '' : password).trim()).slice(0, 16);
}

function pedirNuevaClave(emailIngresado, urlAula) {
  const email = String(emailIngresado || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { error: 'Escribí un mail válido.' };

  const cache = CacheService.getScriptCache();
  const claveEspera = 'reset_' + email.slice(0, 100);
  const respuesta = { ok: true };                 // misma respuesta exista o no el mail
  if (cache.get(claveEspera)) return respuesta;

  const alumno = sheetToObjects('Alumnos').find(a => String(a.Email || '').trim().toLowerCase() === email);
  if (!alumno) return respuesta;

  if (MailApp.getRemainingDailyQuota() < 1) {
    return { error: 'Hoy no podemos enviar más mails. Escribinos por WhatsApp y te ayudamos.' };
  }
  const base = URLS_AULA_PERMITIDAS.indexOf(String(urlAula || '')) !== -1 ? String(urlAula) : URLS_AULA_PERMITIDAS[0];
  const token = crearToken({ t: 'reset', id: String(alumno.ID_Alumno), h: huellaClave(alumno.Password) }, DURACION_LINK_CLAVE_SEG);
  const link = base + '#restablecer=' + token;
  const nombre = String(alumno.Nombre || '').trim().split(' ')[0];
  const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  MailApp.sendEmail({
    to: String(alumno.Email).trim(),
    name: 'Instituto Mariana Barrera',
    subject: 'Creá tu nueva contraseña del Aula Virtual',
    body: 'Hola' + (nombre ? ' ' + nombre : '') + ':\n\n' +
      'Para crear una contraseña nueva del Aula Virtual entrá a este link (vale por 1 hora):\n' + link + '\n\n' +
      'Si no lo pediste vos, ignorá este mail: tu contraseña actual sigue funcionando.\n\nInstituto Mariana Barrera',
    htmlBody:
      '<div style="font-family:Arial,sans-serif;max-width:520px;margin:0 auto;color:#4A4444;line-height:1.6">' +
      '<h2 style="font-family:Georgia,serif;font-weight:normal;color:#4A4444">Hola' + (nombre ? ' ' + esc(nombre) : '') + '</h2>' +
      '<p>Recibimos un pedido para crear una contraseña nueva del <strong>Aula Virtual</strong>.</p>' +
      '<p style="margin:28px 0"><a href="' + esc(link) + '" style="background:#4A4444;color:#ffffff;text-decoration:none;' +
      'padding:14px 26px;border-radius:2px;letter-spacing:1px;font-size:13px;text-transform:uppercase">Crear contraseña nueva</a></p>' +
      '<p style="font-size:13px;color:#726B69">El link vale por 1 hora y sirve una sola vez. Si no lo pediste vos, ignorá este mail: ' +
      'tu contraseña actual sigue funcionando.</p>' +
      '<p style="font-size:13px;color:#726B69">Instituto de Estética y Cosmiatría Mariana Barrera</p></div>'
  });
  cache.put(claveEspera, '1', ESPERA_ENTRE_MAILS_SEG);
  return respuesta;
}

function restablecerClave(token, passwordNueva) {
  const datos = leerToken(token);
  if (!datos || datos.t !== 'reset') return { error: 'Este link venció o no es válido. Pedí uno nuevo desde "¿Olvidaste tu contraseña?".' };
  const nueva = String(passwordNueva || '').trim();
  if (nueva.length < 6) return { error: 'La contraseña tiene que tener al menos 6 caracteres.' };
  if (nueva.length > 60) return { error: 'La contraseña es demasiado larga.' };

  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  let email;
  try {
    const sh = getSheetByName('Alumnos');
    const values = sh.getDataRange().getValues();
    const headers = values[0].map(String);
    const cId = headers.indexOf('ID_Alumno'), cPw = headers.indexOf('Password'), cEmail = headers.indexOf('Email');
    if (cId === -1 || cPw === -1) throw new Error('Falta la columna ID_Alumno o Password en la hoja Alumnos.');
    let fila = -1;
    for (let r = 1; r < values.length; r++) {
      if (String(values[r][cId]).trim() === String(datos.id)) { fila = r; break; }
    }
    if (fila === -1) return { error: 'No encontramos tu cuenta. Escribinos por WhatsApp.' };
    // Si la contraseña ya cambió desde que se mandó el mail, el link ya se usó
    if (!igualesSeguro(huellaClave(values[fila][cPw]), datos.h)) {
      return { error: 'Este link ya se usó. Si necesitás otra contraseña, pedí un link nuevo.' };
    }
    const celda = sh.getRange(fila + 1, cPw + 1);
    celda.setNumberFormat('@');            // texto: así no se pierden ceros adelante
    celda.setValue(nueva);
    email = String(values[fila][cEmail] || '').trim().toLowerCase();
  } finally {
    lock.releaseLock();
  }
  limpiarFallos('alumno_' + email.slice(0, 100));
  // Entra directo al aula con la contraseña nueva
  return loginAlumno(email, nueva);
}

/* ---- Mantener el servidor despierto (opcional, se instala una sola vez) ----
   Ejecutar UNA VEZ instalarDespertador() desde el editor: cada 5 minutos el
   servidor se "despierta" y deja el catálogo listo en memoria, así el primer
   visitante no espera el arranque. */
function mantenerDespierto() {
  getContenido();
}
function instalarDespertador() {
  ScriptApp.getProjectTriggers()
    .filter(t => t.getHandlerFunction() === 'mantenerDespierto')
    .forEach(t => ScriptApp.deleteTrigger(t));
  ScriptApp.newTrigger('mantenerDespierto').timeBased().everyMinutes(5).create();
  mantenerDespierto();
  Logger.log('Listo: el catálogo y el aula se mantienen despiertos (cada 5 minutos).');
}

function loginBloqueado(clave) {
  return Number(CacheService.getScriptCache().get('fallos_' + clave) || 0) >= MAX_INTENTOS_LOGIN;
}
function registrarFallo(clave) {
  const cache = CacheService.getScriptCache();
  const n = Number(cache.get('fallos_' + clave) || 0) + 1;
  cache.put('fallos_' + clave, String(n), BLOQUEO_LOGIN_SEG);
}
function limpiarFallos(clave) {
  CacheService.getScriptCache().remove('fallos_' + clave);
}

function loginAlumno(emailIngresado, passwordIngresada) {
  const email = String(emailIngresado || '').trim().toLowerCase();
  const password = String(passwordIngresada || '').trim();
  const clave = 'alumno_' + email.slice(0, 100);

  if (loginBloqueado(clave)) return { success: false, bloqueado: true };

  const alumno = sheetToObjects('Alumnos').find(a =>
    String(a.Email || '').trim().toLowerCase() === email &&
    String(a.Password || '').trim() === password
  );
  if (!email || !password || !alumno) {
    registrarFallo(clave);
    return { success: false };
  }

  limpiarFallos(clave);
  const idAlumno = String(alumno.ID_Alumno);

  // Se devuelven cursos y certificados en la misma respuesta: el alumno entra con UNA sola llamada
  let datos = null;
  try { datos = getCursosAlumno(idAlumno); } catch (e) { datos = null; }

  return {
    success: true,
    token: crearToken({ t: 'alumno', id: idAlumno }, DURACION_SESION_SEG),
    alumno: { Nombre: alumno.Nombre },
    cursos: datos ? datos.cursos : null,
    certificados: datos ? datos.certificados : null,
    avance: datos ? datos.avance : null
  };
}

/* ============================================================
   CATÁLOGO
   ============================================================ */

/** Un curso está publicado si hoy cae dentro de sus fechas de publicación. */
function estaPublicado(c, hoy) {
  if (c.Fecha_Inicio_Publicacion) {
    const fi = new Date(c.Fecha_Inicio_Publicacion);
    if (!isNaN(fi) && fi > hoy) return false;
  }
  if (c.Fecha_Fin_Publicacion) {
    const ff = new Date(c.Fecha_Fin_Publicacion);
    if (!isNaN(ff) && ff < hoy) return false;
  }
  return true;
}

/** Catálogo público liviano (sin Descripcion_Larga), con caché. */
function getCatalogoPublico() {
  const cache = CacheService.getScriptCache();
  const version = getVersionContenido();
  const cached = cache.get(CACHE_KEY_CATALOGO);
  if (cached) {
    const c = JSON.parse(cached);
    if (c && c.version === version) return c.cursos;
  }

  const hoy = new Date();
  const catalogo = getContenido().cursos.filter(c => estaPublicado(c, hoy)).map(c => ({
    ID_Curso: c.ID_Curso,
    Nombre: c.Nombre,
    Descripcion_Programa: c.Descripcion_Programa,
    Imagen_URL: c.Imagen_URL,
    Duracion: c.Duracion,
    Nivel: c.Nivel || '',
    Precio_ARS: c.Precio_ARS,
    Precio_USD: c.Precio_USD,
    Destacado: !!c.Destacado,
    Etiqueta: c.Etiqueta || '',
    Fecha_Inicio_Curso: c.Fecha_Inicio_Curso || ''
  }));

  try {
    cache.put(CACHE_KEY_CATALOGO, JSON.stringify({ version: version, cursos: catalogo }), CACHE_TTL_SECONDS);
  } catch (e) {
    console.warn('No se pudo cachear el catálogo: ' + e.message);
  }
  return catalogo;
}

/**
 * Página del curso PUBLICADO para el catálogo.
 * El temario lleva SOLO tipo y nombre de cada contenido: nunca los links,
 * así nadie puede ver los videos o PDF sin estar inscripto.
 */
function getCursoDetalle(idCurso) {
  const contenido = getContenido();
  const curso = contenido.cursos.find(c => String(c.ID_Curso) === String(idCurso));
  if (!curso || !estaPublicado(curso, new Date())) return { error: 'Curso no encontrado' };
  const temario = (contenido.clasesPorCurso[String(curso.ID_Curso)] || []).map(cl => ({
    Titulo: cl.Titulo,
    Items: (cl.Contenidos || []).map(x => ({ Tipo: x.Tipo, Nombre: x.Nombre }))
  }));
  return {
    ID_Curso: curso.ID_Curso,
    Nombre: curso.Nombre,
    Descripcion_Programa: curso.Descripcion_Programa,
    Descripcion_Larga: curso.Descripcion_Larga || '',
    Imagen_URL: curso.Imagen_URL,
    Duracion: curso.Duracion,
    Nivel: curso.Nivel || '',
    Requisitos: curso.Requisitos || '',
    Precio_ARS: curso.Precio_ARS,
    Precio_USD: curso.Precio_USD,
    Temario: temario,
    Preguntas: contenido.preguntas || []
  };
}

/* ============================================================
   CLASSROOM DEL ALUMNO
   ============================================================ */

function getCursosAlumno(idAlumnoDelToken) {
  const idAlumno = String(idAlumnoDelToken).trim();

  // Las inscripciones se leen siempre en vivo (así habilitar/deshabilitar es inmediato)
  const idsHabilitados = {};
  sheetToObjects('Inscripciones').forEach(i => {
    if (String(i.ID_Alumno).trim() !== idAlumno) return;
    if (String(i.Habilitado || '').trim().toLowerCase() !== 'si') return;
    idsHabilitados[String(i.ID_Curso).trim()] = i;
  });

  const contenido = getContenido();
  const intentos = intentosDelAlumno(idAlumno);
  const cursos = contenido.cursos
    .filter(c => idsHabilitados[String(c.ID_Curso).trim()])
    .map(c => ({
      ID_Curso: c.ID_Curso,
      Nombre: c.Nombre,
      Descripcion_Programa: c.Descripcion_Programa,
      Descripcion_Larga: c.Descripcion_Larga,
      Imagen_URL: c.Imagen_URL,
      Duracion: c.Duracion,
      Clases: contenido.clasesPorCurso[String(c.ID_Curso)] || [],
      Examen: resumenExamen(contenido.examenesPorCurso[String(c.ID_Curso)],
        idsHabilitados[String(c.ID_Curso).trim()], intentos)
    }));

  return { cursos: cursos, certificados: getCertificadosAlumno(idAlumno), avance: getAvanceAlumno(idAlumno) };
}

/* ============================================================
   EXAMEN FINAL
   - Se habilita cuando el alumno completó todas las clases del curso.
   - Las respuestas correctas nunca salen del servidor.
   - El alumno solo ve "Aprobado" o "No aprobado"; el puntaje queda para el admin.
   ============================================================ */

function hojaResultados() {
  const ss = getSS();
  let sh = ss.getSheetByName(HOJA_RESULTADOS);
  if (!sh) {
    sh = ss.insertSheet(HOJA_RESULTADOS);
    sh.getRange(1, 1, 1, COLUMNAS_RESULTADOS.length).setValues([COLUMNAS_RESULTADOS]).setFontWeight('bold');
    sh.setFrozenRows(1);
  }
  return sh;
}

/** Intentos del alumno (todas las filas de Resultados_Examen que son suyas). */
function intentosDelAlumno(idAlumno) {
  if (!getSS().getSheetByName(HOJA_RESULTADOS)) return [];
  const id = String(idAlumno).trim();
  return sheetToObjects(HOJA_RESULTADOS).filter(r => String(r.ID_Alumno).trim() === id);
}

function intentoVencido(r, ahora) {
  const limite = Number(r.Limite_Ms);
  return !!limite && ahora > limite + GRACIA_EXAMEN_MS;
}

/** Lo que el alumno necesita saber del examen de un curso (sin preguntas ni respuestas). */
function resumenExamen(examen, inscripcion, intentos) {
  if (!examen || !examen.Publicado || !examen.Preguntas.length) return null;
  const ahora = Date.now();
  const propios = (intentos || []).filter(r => String(r.ID_Examen) === examen.ID_Examen);
  const extra = Math.max(0, Number(inscripcion && inscripcion.Intentos_Extra) || 0);
  const total = examen.Intentos_Max + extra;
  const aprobado = propios.some(r => String(r.Aprobado || '').trim().toLowerCase() === 'si');
  const enCurso = propios.some(r => String(r.Estado) === 'En curso' && !intentoVencido(r, ahora));
  const finalizados = propios.filter(r => String(r.Estado) !== 'En curso' || intentoVencido(r, ahora));
  return {
    Titulo: examen.Titulo,
    Instrucciones: examen.Instrucciones,
    Preguntas: examen.Preguntas.length,
    Tiempo_Min: examen.Tiempo_Min,
    Nota_Minima: examen.Nota_Minima,
    Intentos_Total: total,
    Usados: propios.length,
    Restantes: Math.max(0, total - propios.length),
    Aprobado: aprobado,
    EnCurso: enCurso && !aprobado,
    Rendido: finalizados.length > 0
  };
}

/** Busca la inscripción habilitada del alumno al curso; si no existe, error. */
function inscripcionHabilitada(idAlumno, idCurso) {
  const insc = sheetToObjects('Inscripciones').find(i =>
    String(i.ID_Alumno).trim() === idAlumno &&
    String(i.ID_Curso).trim() === idCurso &&
    String(i.Habilitado || '').trim().toLowerCase() === 'si');
  if (!insc) throw new Error('No tenés acceso a este curso.');
  return insc;
}

function mezclar(lista) {
  const a = lista.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const t = a[i]; a[i] = a[j]; a[j] = t;
  }
  return a;
}

/** Arma lo que se le manda al navegador: preguntas y opciones, SIN la correcta. */
function paqueteExamen(examen, fila, ahora) {
  const porId = {};
  examen.Preguntas.forEach(p => { porId[p.ID] = p; });
  const orden = String(fila.Orden_Preguntas || '').split(',').map(s => s.trim()).filter(id => porId[id]);
  const limite = Number(fila.Limite_Ms) || 0;
  return {
    ok: true,
    idIntento: String(fila.ID_Intento),
    intento: Number(fila.Intento) || 1,
    titulo: examen.Titulo,
    instrucciones: examen.Instrucciones,
    segundosRestantes: limite ? Math.max(0, Math.floor((limite - ahora) / 1000)) : null,
    preguntas: orden.map(id => ({ ID: id, Pregunta: porId[id].Pregunta, Opciones: porId[id].Opciones }))
  };
}

function leerFilasResultados(sh) {
  const values = sh.getDataRange().getValues();
  const headers = values[0].map(String);
  const filas = [];
  for (let r = 1; r < values.length; r++) {
    const o = { _fila: r + 1 };
    headers.forEach((h, k) => { o[h] = values[r][k]; });
    filas.push(o);
  }
  return { headers: headers, filas: filas };
}

function escribirFilaResultado(sh, headers, numFila, datos) {
  const fila = headers.map(h => datos[h] !== undefined ? datos[h] : '');
  if (numFila) sh.getRange(numFila, 1, 1, headers.length).setValues([fila]);
  else sh.appendRow(fila);
}

function ahoraTexto() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss');
}

function iniciarExamen(idAlumnoToken, idCursoPedido) {
  const idAlumno = String(idAlumnoToken).trim();
  const idCurso = String(idCursoPedido || '').trim();
  const insc = inscripcionHabilitada(idAlumno, idCurso);

  const contenido = getContenido();
  const examen = contenido.examenesPorCurso[idCurso];
  if (!examen || !examen.Publicado || !examen.Preguntas.length) throw new Error('Este curso todavía no tiene examen.');

  // Tiene que haber completado TODAS las clases del curso
  const clases = contenido.clasesPorCurso[idCurso] || [];
  const avance = getAvanceAlumno(idAlumno);
  const faltan = clases.filter(cl => !(avance[String(cl.ID_Clase)] && avance[String(cl.ID_Clase)].completa)).length;
  if (faltan) throw new Error('Para rendir el examen tenés que completar todas las clases (te ' +
    (faltan === 1 ? 'falta 1' : 'faltan ' + faltan) + ').');

  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const sh = hojaResultados();
    const { headers, filas } = leerFilasResultados(sh);
    const ahora = Date.now();
    const propias = filas.filter(r => String(r.ID_Alumno).trim() === idAlumno && String(r.ID_Examen) === examen.ID_Examen);

    // Intentos que quedaron abiertos y se pasaron del tiempo: se cierran sin puntaje
    propias.forEach(r => {
      if (String(r.Estado) === 'En curso' && intentoVencido(r, ahora)) {
        r.Estado = 'Finalizado'; r.Fin = ahoraTexto(); r.Correctas = 0; r.Puntaje = 0; r.Aprobado = 'No';
        r.Respuestas = r.Respuestas || '{}';
        escribirFilaResultado(sh, headers, r._fila, r);
      }
    });

    if (propias.some(r => String(r.Aprobado || '').trim().toLowerCase() === 'si')) {
      throw new Error('Ya aprobaste este examen.');
    }
    const abierto = propias.find(r => String(r.Estado) === 'En curso');
    if (abierto) return paqueteExamen(examen, abierto, ahora);     // retoma el que tenía empezado

    const total = examen.Intentos_Max + Math.max(0, Number(insc.Intentos_Extra) || 0);
    if (propias.length >= total) throw new Error('Ya usaste todos tus intentos. Comunicate con el instituto.');

    const ids = examen.Preguntas.map(p => p.ID);
    const nuevo = {
      ID_Intento: 'INT-' + Utilities.getUuid().replace(/-/g, '').slice(0, 12).toUpperCase(),
      ID_Alumno: idAlumno,
      ID_Curso: idCurso,
      ID_Examen: examen.ID_Examen,
      Intento: propias.length + 1,
      Estado: 'En curso',
      Inicio: ahoraTexto(),
      Limite_Ms: examen.Tiempo_Min ? ahora + examen.Tiempo_Min * 60 * 1000 : '',
      Orden_Preguntas: (examen.Mezclar ? mezclar(ids) : ids).join(','),
      Total: ids.length
    };
    escribirFilaResultado(sh, headers, 0, nuevo);
    return paqueteExamen(examen, nuevo, ahora);
  } finally {
    lock.releaseLock();
  }
}

function enviarExamen(idAlumnoToken, idIntento, respuestasEnviadas) {
  const idAlumno = String(idAlumnoToken).trim();
  const contenido = getContenido();

  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  let resultado;
  let idCurso;
  try {
    const sh = hojaResultados();
    const { headers, filas } = leerFilasResultados(sh);
    const fila = filas.find(r => String(r.ID_Intento) === String(idIntento || '') && String(r.ID_Alumno).trim() === idAlumno);
    if (!fila) throw new Error('No se encontró el examen. Volvé a entrar al curso.');
    if (String(fila.Estado) !== 'En curso') throw new Error('Este examen ya fue enviado.');
    idCurso = String(fila.ID_Curso);
    const examen = contenido.examenesPorCurso[idCurso];
    if (!examen || examen.ID_Examen !== String(fila.ID_Examen)) throw new Error('El examen ya no está disponible. Comunicate con el instituto.');

    const porId = {};
    examen.Preguntas.forEach(p => { porId[p.ID] = p; });
    const orden = String(fila.Orden_Preguntas || '').split(',').map(s => s.trim()).filter(id => porId[id]);
    const enviadas = (respuestasEnviadas && typeof respuestasEnviadas === 'object') ? respuestasEnviadas : {};
    const respuestas = {};
    orden.forEach(id => {
      const r = String(enviadas[id] || '').trim().toUpperCase();
      if (['A', 'B', 'C', 'D'].indexOf(r) !== -1) respuestas[id] = r;
    });

    // Si llegó mucho después del tiempo límite, el intento cuenta sin puntaje
    const tarde = intentoVencido(fila, Date.now());
    const correctas = tarde ? 0 : orden.filter(id => respuestas[id] === porId[id].Correcta).length;
    const totalPreg = orden.length;
    const puntaje = totalPreg ? Math.round(correctas / totalPreg * 100) : 0;
    const aprobado = !tarde && totalPreg > 0 && puntaje >= examen.Nota_Minima;

    fila.Estado = 'Finalizado';
    fila.Fin = ahoraTexto();
    fila.Respuestas = JSON.stringify(respuestas);
    fila.Correctas = correctas;
    fila.Total = totalPreg;
    fila.Puntaje = puntaje;
    fila.Aprobado = aprobado ? 'Si' : 'No';
    escribirFilaResultado(sh, headers, fila._fila, fila);
    resultado = { ok: true, aprobado: aprobado, tarde: tarde };
  } finally {
    lock.releaseLock();
  }

  // Resumen actualizado para la pantalla del alumno (sin puntaje)
  const insc = sheetToObjects('Inscripciones').find(i =>
    String(i.ID_Alumno).trim() === idAlumno && String(i.ID_Curso).trim() === idCurso);
  resultado.examen = resumenExamen(contenido.examenesPorCurso[idCurso], insc, intentosDelAlumno(idAlumno));
  return resultado;
}

/* ============================================================
   AVANCE DEL ALUMNO (hoja "Avance": una fila por alumno y clase)
   ============================================================ */

const HOJA_AVANCE = 'Avance';
const COLUMNAS_AVANCE = ['ID_Alumno', 'ID_Curso', 'ID_Clase', 'Items_Vistos', 'Completada', 'Ultima_Actividad'];

function hojaAvance() {
  const ss = getSS();
  let sh = ss.getSheetByName(HOJA_AVANCE);
  if (!sh) {
    sh = ss.insertSheet(HOJA_AVANCE);
    sh.getRange(1, 1, 1, COLUMNAS_AVANCE.length).setValues([COLUMNAS_AVANCE]).setFontWeight('bold');
    sh.setFrozenRows(1);
  }
  return sh;
}

function separarItems(v) {
  return String(v || '').split(',').map(s => s.trim()).filter(Boolean);
}

/** { ID_Clase: { items: [ID_Material...], completa: true/false } } del alumno */
function getAvanceAlumno(idAlumno) {
  const sh = getSS().getSheetByName(HOJA_AVANCE);
  if (!sh) return {};
  const id = String(idAlumno).trim();
  const avance = {};
  sheetToObjects(HOJA_AVANCE).forEach(r => {
    if (String(r.ID_Alumno).trim() !== id) return;
    avance[String(r.ID_Clase)] = {
      items: separarItems(r.Items_Vistos),
      completa: String(r.Completada || '').trim().toLowerCase() === 'si'
    };
  });
  return avance;
}

/**
 * Registra avance. body: { idClase, idItem? , completar? (true/false) }
 *  - idItem: marca ese contenido como visto; si ya vio todos, la clase queda completa.
 *  - completar: el alumno marca o desmarca la clase a mano.
 */
function marcarAvance(idAlumno, body) {
  const alumno = String(idAlumno).trim();
  const idClase = String(body.idClase || '').trim();
  if (!idClase) throw new Error('Falta la clase.');

  // La clase tiene que existir y pertenecer a un curso habilitado para este alumno
  const contenido = getContenido();
  let idCurso = null, clase = null;
  Object.keys(contenido.clasesPorCurso).forEach(k => {
    const c = contenido.clasesPorCurso[k].find(cl => String(cl.ID_Clase) === idClase);
    if (c) { idCurso = k; clase = c; }
  });
  if (!clase) throw new Error('La clase no existe.');
  const habilitado = sheetToObjects('Inscripciones').some(i =>
    String(i.ID_Alumno).trim() === alumno &&
    String(i.ID_Curso).trim() === String(idCurso).trim() &&
    String(i.Habilitado || '').trim().toLowerCase() === 'si');
  if (!habilitado) throw new Error('No tenés acceso a esta clase.');

  const idsItems = (clase.Contenidos || []).map(c => String(c.ID)).filter(Boolean);

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const sh = hojaAvance();
    const values = sh.getDataRange().getValues();
    const headers = values[0].map(String);
    const col = n => headers.indexOf(n);
    let fila = -1;
    for (let r = 1; r < values.length; r++) {
      if (String(values[r][col('ID_Alumno')]).trim() === alumno && String(values[r][col('ID_Clase')]).trim() === idClase) {
        fila = r; break;
      }
    }
    const items = new Set(fila > 0 ? separarItems(values[fila][col('Items_Vistos')]) : []);
    let completa = fila > 0 && String(values[fila][col('Completada')]).trim().toLowerCase() === 'si';

    if (body.idItem && idsItems.indexOf(String(body.idItem)) !== -1) {
      items.add(String(body.idItem));
      if (idsItems.length && idsItems.every(i => items.has(i))) completa = true;
    }
    if (body.completar === true) completa = true;
    if (body.completar === false) completa = false;

    const datos = {
      ID_Alumno: alumno, ID_Curso: idCurso, ID_Clase: idClase,
      Items_Vistos: Array.from(items).join(','),
      Completada: completa ? 'Si' : 'No',
      Ultima_Actividad: Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm')
    };
    const filaValores = headers.map(hd => datos[hd] !== undefined ? datos[hd] : '');
    if (fila > 0) sh.getRange(fila + 1, 1, 1, headers.length).setValues([filaValores]);
    else sh.appendRow(filaValores);

    return { ok: true, idClase: idClase, items: Array.from(items), completa: completa };
  } finally {
    lock.releaseLock();
  }
}

/* ============================================================
   CERTIFICADOS DEL ALUMNO
   ============================================================ */

function limpiarDni(v) { return String(v || '').replace(/[.\s]/g, '').trim(); }

/** Certificados ya emitidos (con PDF) del alumno, del más nuevo al más viejo. */
function getCertificadosAlumno(idAlumno) {
  const dni = limpiarDni(idAlumno);
  if (!dni) return [];
  let egresados;
  try { egresados = sheetToObjects('Egresados'); } catch (e) { return []; }
  return egresados
    .filter(e => limpiarDni(e.DNI) === dni && String(e.URL_PDF || '').trim() !== '')
    .reverse()
    .map(e => ({
      Curso: String(e.Curso || ''),
      Tipo: String(e.Tipo || 'Diploma'),
      Fecha: formatearFechaCertificado(e.Fecha),
      Certificado: String(e.Certificado || ''),
      URL_PDF: String(e.URL_PDF || '').trim()
    }));
}

/** Convierte la fecha a "Mes Año" (igual que en el certificado). */
function formatearFechaCertificado(valor) {
  if (valor === '' || valor === null || valor === undefined) return '';
  const meses = ['Enero','Febrero','Marzo','Abril','Mayo','Junio',
    'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
  const tz = Session.getScriptTimeZone();
  const aMesAnio = d => meses[Number(Utilities.formatDate(d, tz, 'M')) - 1] + ' ' + Utilities.formatDate(d, tz, 'yyyy');
  if (Object.prototype.toString.call(valor) === '[object Date]' && !isNaN(valor.getTime())) return aMesAnio(valor);
  const texto = String(valor).trim();
  if (/^[A-Za-zÁÉÍÓÚáéíóú]+\s+\d{4}$/.test(texto)) return texto.charAt(0).toUpperCase() + texto.slice(1);
  const fecha = new Date(texto);
  if (!isNaN(fecha.getTime())) return aMesAnio(fecha);
  return texto;
}

/* ============================================================
   doGet / doPost
   ============================================================ */

function doGet(e) {
  try {
    const action = e && e.parameter && e.parameter.action;

    if (action === 'catalogo') {
      return respond({ cursos: getCatalogoPublico() });
    }

    if (action === 'detalle') {
      return respond(getCursoDetalle(e.parameter.id || ''));
    }

    if (action === 'limpiarCache') {
      if (!igualesSeguro(e.parameter.key || '', CLAVE_LIMPIEZA)) {
        return respond({ ok: false, error: 'No autorizado' });
      }
      limpiarTodoElCache();
      return respond({ ok: true, mensaje: 'Caché limpiado.' });
    }

    return respond({ ok: true, mensaje: 'API del classroom Academia Virtual activa' });
  } catch (err) {
    return respond({ error: err.message });
  }
}

function doPost(e) {
  let body;
  try { body = JSON.parse(e.postData.contents); }
  catch (err) { return respond({ error: 'Cuerpo de la petición inválido' }); }

  try {
    switch (body.action) {

      case 'loginAlumno':
        return respond(loginAlumno(body.email, body.password));

      case 'pedirNuevaClave':
        return respond(pedirNuevaClave(body.email, body.urlAula));

      case 'restablecerClave':
        return respond(restablecerClave(body.token, body.password));

      case 'getCursosAlumno': {
        // El alumno sale del token firmado, NUNCA de un dato enviado por el navegador
        const sesion = leerToken(body.token);
        if (!sesion || sesion.t !== 'alumno') {
          return respond({ sesionInvalida: true, error: 'Tu sesión venció. Volvé a ingresar.' });
        }
        return respond(getCursosAlumno(sesion.id));
      }

      case 'marcarAvance': {
        const sesion = leerToken(body.token);
        if (!sesion || sesion.t !== 'alumno') {
          return respond({ sesionInvalida: true, error: 'Tu sesión venció. Volvé a ingresar.' });
        }
        return respond(marcarAvance(sesion.id, body));
      }

      case 'iniciarExamen':
      case 'enviarExamen': {
        const sesion = leerToken(body.token);
        if (!sesion || sesion.t !== 'alumno') {
          return respond({ sesionInvalida: true, error: 'Tu sesión venció. Volvé a ingresar.' });
        }
        return respond(body.action === 'iniciarExamen'
          ? iniciarExamen(sesion.id, body.idCurso)
          : enviarExamen(sesion.id, body.idIntento, body.respuestas));
      }

      default:
        return respond({ error: 'Acción no reconocida: ' + body.action });
    }
  } catch (err) {
    return respond({ error: err.message });
  }
}
