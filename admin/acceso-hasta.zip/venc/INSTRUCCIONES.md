# Fecha "Acceso hasta" por inscripción

Hacé los pasos **en este orden**. La columna de la planilla va primero, después el script y por último las páginas.

## Paso 1: Planilla (columna nueva)
1. Abrí la planilla de la Academia → hoja **Inscripciones**.
2. En la primera columna vacía de la fila 1 escribí exactamente: `Acceso_Hasta`
3. Seleccioná esa columna entera → **Formato → Número → Fecha**.
   Las inscripciones que ya existen quedan vacías: **no vencen** hasta que les cargues una fecha.

## Paso 2: Apps Script del aula y del catálogo (v10 → v11)
1. **Extensiones → Apps Script** → proyecto del **aula del alumno**.
2. Abrí el archivo `.gs` → `Ctrl + A` → borrá todo.
3. Abrí `apps-script/script_alumno_y_catalogo_v11.gs` con el Bloc de notas → `Ctrl + A` → `Ctrl + C` → pegá en el editor → **Guardar** (ícono del disquete).
4. **Implementar → Administrar implementaciones → ✏️ (lápiz) → Versión: Nueva versión → Implementar.**
   ⚠️ No elijas "Nueva implementación": eso cambia la URL `/exec` y el aula dejaría de conectarse.

## Paso 3: Páginas (GitHub)
Igual que siempre: archivo → lápiz → `Ctrl + A` → pegar el contenido nuevo → **Commit changes**.
- `aula/index.html` ← `aula/index.html` de esta carpeta (incluye la cabecera con la foto de bienvenida)
- `admin/index.html` ← `admin/index.html` de esta carpeta

## Paso 4: Probar (10 minutos)
1. **Panel admin** → Inscripciones → **Editar** en una inscripción de prueba → en **"Acceso hasta"** poné la fecha de **ayer** → Guardar.
   - En la tabla tiene que aparecer la fecha con la etiqueta roja **Vencido**.
   - En la planilla, la columna `Acceso_Hasta` de esa fila tiene que tener la fecha.
     **Si la celda quedó vacía**, el script del panel no está guardando el campo nuevo: mandame el código del Apps Script del panel y lo ajusto.
2. **Aula** → ingresá con ese alumno: el curso aparece en gris con **"Acceso vencido el …"** y el botón **"Renovar por WhatsApp"**.
3. Volvé al panel y cambiá la fecha a una **futura** → en el aula (tocá `Ctrl + F5`) el curso se abre normal y muestra **"Disponible hasta el …"**.
4. Borrá la fecha → el curso vuelve a no tener vencimiento.

## Cómo funciona
- El **último día** cargado el alumno todavía puede entrar; se corta al día siguiente.
- Curso vencido: el servidor **no manda** las clases, los videos ni los PDF, y no deja marcar avance ni empezar el examen.
- Si un examen ya estaba **empezado** antes de vencer, se puede terminar y enviar.
- Los **certificados** siguen disponibles siempre.
- Para dar una prórroga o renovar: cambiá la fecha en el panel. Se aplica en el acto.
- Además de la fecha, "Habilitado = No" sigue funcionando como hasta ahora: corta el acceso y el curso ni siquiera aparece.

## Volver atrás
Los archivos originales están en `respaldo/`. Si pegás de nuevo el script v10 y las páginas originales, todo queda como antes (la columna `Acceso_Hasta` se ignora).
